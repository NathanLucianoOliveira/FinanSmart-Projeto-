﻿using FinanSmart.Dominio.Entities;

namespace FinanSmart.Dominio.Interface.Repository
{
    public interface IcategoriaRepository
    {
        public void AdicionarCategoria(Categoria categoria); 
    }
}

﻿using FinanSmart.Dominio.Entities;

namespace FinanSmart.Dominio.Interface.Serviços
{
    public interface ICategoriaServico
    {
        public void AdicionarCategoria(Categoria categoria);
    }
}


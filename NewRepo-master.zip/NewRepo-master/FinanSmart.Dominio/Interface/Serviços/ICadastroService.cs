﻿using FinanSmart.Dominio.ValueObjects;

namespace FinanSmart.Dominio.Interface.Serviços
{
    public interface ICadastroService
    {
        public void AdicionarCadastro(Cadastro cadastro);
    }
}

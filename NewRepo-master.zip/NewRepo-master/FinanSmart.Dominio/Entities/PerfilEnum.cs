﻿
namespace FinanSmart.Dominio.Entities
{
    public enum PerfilEnum
    {
        Admin = 1,
        Padrao = 2,
    }
}

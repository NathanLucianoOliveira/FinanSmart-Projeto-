﻿namespace FinanSmart.Dominio.Entities
{
    public class Categoria
    {
        public int CategoriaID { get; set; }
        public string CategoriaNome { get; set; }
        public string CategoriaDescricao { get; set; }
    }

}

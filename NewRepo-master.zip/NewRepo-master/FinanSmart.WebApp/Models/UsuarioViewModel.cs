﻿
public class UsuarioViewModel
{
    public string Usuario { get; set; }
    public string Senha { get; set; }
    public bool ManterConectado { get; set; } = true;

}